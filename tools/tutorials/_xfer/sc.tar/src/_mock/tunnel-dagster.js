var $=function(i){return document.getElementById(i)};
(function(){var t=localStorage.getItem('hydra-theme');if(t)document.documentElement.setAttribute('data-theme',t);
$("themeBtn").onclick=function(){var d=document.documentElement,n=d.getAttribute('data-theme')==='dark'?'light':'dark';d.setAttribute('data-theme',n);localStorage.setItem('hydra-theme',n)};
var b=$("burger"),dr=$("drawer");b.onclick=function(){var o=dr.classList.toggle('open');b.setAttribute('aria-expanded',o)};
document.addEventListener('click',function(e){if(dr.classList.contains('open')&&!dr.contains(e.target)&&!b.contains(e.target)){dr.classList.remove('open');b.setAttribute('aria-expanded','false')}});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&dr.classList.contains('open')){dr.classList.remove('open');b.setAttribute('aria-expanded','false');b.focus()}});})();
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

var EX=[
{n:'Daily orders → Parquet',f:'daily_orders.py',s:
'from dagster import asset, Definitions, ScheduleDefinition, define_asset_job, RetryPolicy, EnvVar\n'+
'from dagster_postgres import PostgresResource\n'+
'import pandas as pd\n'+
'\n'+
'@asset(retry_policy=RetryPolicy(max_retries=3, delay=300))\n'+
'def daily_orders(context, warehouse: PostgresResource) -> None:\n'+
'    with warehouse.get_connection() as conn:\n'+
'        df = pd.read_sql("SELECT * FROM orders", conn)\n'+
'    context.log.info("read %s rows", len(df))\n'+
'    df = df[df.amount > 0]\n'+
'    df = df.groupby("region").amount.sum().reset_index()\n'+
'    df.to_parquet("s3://warehouse/orders.parquet")\n'+
'\n'+
'orders_job = define_asset_job("orders_job", selection=[daily_orders])\n'+
'\n'+
'defs = Definitions(\n'+
'    assets=[daily_orders],\n'+
'    schedules=[ScheduleDefinition(job=orders_job, cron_schedule="0 2 * * *")],\n'+
'    resources={"warehouse": PostgresResource(url=EnvVar("DWH_URL"))},\n'+
')\n'},
{n:'CSV → Postgres, cleaned',f:'load_signups.py',s:
'from dagster import asset, Definitions, ScheduleDefinition, define_asset_job, RetryPolicy\n'+
'import pandas as pd\n'+
'\n'+
'@asset(retry_policy=RetryPolicy(max_retries=2, delay=60))\n'+
'def signups(context) -> None:\n'+
'    df = pd.read_csv("/data/landing/signups.csv")\n'+
'    df = df.rename(columns={"e_mail": "email", "ts": "signed_up_at"})\n'+
'    df = df.fillna({"country": "unknown"})\n'+
'    df = df.drop_duplicates(subset=["email"])\n'+
'    df = df[df.email.notnull()]\n'+
'    df.to_sql("signups", context.resources.dwh.get_engine(), if_exists="append", index=False)\n'+
'\n'+
'job = define_asset_job("signups_job", selection=[signups])\n'+
'defs = Definitions(assets=[signups], schedules=[ScheduleDefinition(job=job, cron_schedule="0 * * * *")])\n'},
{n:'REST API → Parquet',f:'sync_products.py',s:
'from dagster import asset, Definitions, ScheduleDefinition, define_asset_job, EnvVar\n'+
'import pandas as pd, requests\n'+
'\n'+
'@asset\n'+
'def products() -> None:\n'+
'    key = EnvVar("SHOP_API_KEY").get_value()\n'+
'    r = requests.get("https://api.shop.io/v2/products", headers={"x-key": key})\n'+
'    df = pd.json_normalize(r.json()["items"])\n'+
'    df = df[["sku", "title", "price", "stock"]]\n'+
'    df = df.astype({"price": "float64", "stock": "int64"})\n'+
'    df = df[df.stock > 0]\n'+
'    df.to_parquet("/warehouse/products.parquet")\n'+
'\n'+
'job = define_asset_job("products_job", selection=[products])\n'+
'defs = Definitions(assets=[products], schedules=[ScheduleDefinition(job=job, cron_schedule="0 */6 * * *")])\n'},
{n:'Asset that returns a frame',f:'io_manager_asset.py',s:
'from dagster import asset, Definitions\n'+
'import pandas as pd\n'+
'\n'+
'@asset(io_manager_key="warehouse_io")\n'+
'def clean_customers() -> pd.DataFrame:\n'+
'    df = pd.read_parquet("/lake/raw/customers.parquet")\n'+
'    df = df.drop_duplicates(subset=["customer_id"])\n'+
'    df = df.sort_values("created_at", ascending=False)\n'+
'    df = df[["customer_id", "email", "country", "created_at"]]\n'+
'    return df\n'+
'\n'+
'defs = Definitions(assets=[clean_customers])\n'},
{n:'Partitioned asset',f:'partitioned_events.py',s:
'from dagster import asset, DailyPartitionsDefinition, Definitions, define_asset_job\n'+
'from dagster import build_schedule_from_partitioned_job\n'+
'import pandas as pd\n'+
'\n'+
'@asset(partitions_def=DailyPartitionsDefinition(start_date="2026-01-01"))\n'+
'def events(context) -> None:\n'+
'    day = context.partition_key\n'+
'    df = pd.read_parquet(f"/lake/events/{day}.parquet")\n'+
'    df = df[df.kind != "debug"]\n'+
'    df = df.groupby(["kind"]).agg({"n": "sum"}).reset_index()\n'+
'    df.to_parquet(f"/marts/events/{day}.parquet")\n'+
'\n'+
'job = define_asset_job("events_job", selection=[events])\n'+
'schedule = build_schedule_from_partitioned_job(job)\n'+
'defs = Definitions(assets=[events], schedules=[schedule])\n'},
{n:'Two assets, one depends on the other',f:'asset_graph.py',s:
'from dagster import asset, Definitions\n'+
'import pandas as pd\n'+
'\n'+
'@asset\n'+
'def raw_orders() -> pd.DataFrame:\n'+
'    return pd.read_csv("/lake/raw/orders.csv")\n'+
'\n'+
'@asset\n'+
'def paid_orders(raw_orders: pd.DataFrame) -> None:\n'+
'    df = raw_orders[raw_orders.status == "paid"]\n'+
'    df = df.groupby("region").agg({"total": "sum"}).reset_index()\n'+
'    df.to_parquet("/marts/paid_orders.parquet")\n'+
'\n'+
'defs = Definitions(assets=[raw_orders, paid_orders])\n'},
{n:'Asset check',f:'checked_asset.py',s:
'from dagster import asset, asset_check, AssetCheckResult, Definitions\n'+
'import pandas as pd\n'+
'\n'+
'@asset\n'+
'def invoices() -> None:\n'+
'    df = pd.read_parquet("/lake/invoices.parquet")\n'+
'    df = df[df.total > 0]\n'+
'    df.to_parquet("/marts/invoices.parquet")\n'+
'\n'+
'@asset_check(asset=invoices)\n'+
'def no_null_ids() -> AssetCheckResult:\n'+
'    df = pd.read_parquet("/marts/invoices.parquet")\n'+
'    return AssetCheckResult(passed=bool(df.invoice_id.notnull().all()))\n'+
'\n'+
'defs = Definitions(assets=[invoices], asset_checks=[no_null_ids])\n'},
{n:'Multi-asset',f:'multi_asset.py',s:
'from dagster import multi_asset, AssetOut, Definitions\n'+
'import pandas as pd\n'+
'\n'+
'@multi_asset(outs={"daily": AssetOut(), "weekly": AssetOut()})\n'+
'def rollups():\n'+
'    df = pd.read_parquet("/lake/sales.parquet")\n'+
'    df = df[df.channel != "test"]\n'+
'    daily = df.groupby(["day"]).agg({"net": "sum"}).reset_index()\n'+
'    weekly = df.groupby(["week"]).agg({"net": "sum"}).reset_index()\n'+
'    return daily, weekly\n'+
'\n'+
'defs = Definitions(assets=[rollups])\n'},
{n:'Dagster 0.x legacy pipeline',f:'legacy_pipeline.py',s:
'from dagster import solid, pipeline, ModeDefinition, PresetDefinition\n'+
'import pandas as pd\n'+
'\n'+
'@solid\n'+
'def extract(context):\n'+
'    df = pd.read_csv("/data/in.csv")\n'+
'    df = df.drop_duplicates(subset=["id"])\n'+
'    df.to_parquet("/lake/out.parquet")\n'+
'\n'+
'@pipeline(mode_defs=[ModeDefinition("prod")])\n'+
'def legacy_pipeline():\n'+
'    extract()\n'},
{n:'Auto-materialize + freshness',f:'auto_asset.py',s:
'from dagster import asset, AutoMaterializePolicy, FreshnessPolicy, Definitions\n'+
'import pandas as pd\n'+
'\n'+
'@asset(\n'+
'    auto_materialize_policy=AutoMaterializePolicy.eager(),\n'+
'    freshness_policy=FreshnessPolicy(maximum_lag_minutes=60),\n'+
')\n'+
'def catalog() -> None:\n'+
'    df = pd.read_json("/feeds/catalog.json")\n'+
'    df = df.rename(columns={"Id": "sku"})\n'+
'    df = df[df.sku.notnull()]\n'+
'    df.to_parquet("/lake/catalog.parquet")\n'+
'\n'+
'defs = Definitions(assets=[catalog])\n'}];

var PRESET={'@daily':'0 0 * * *','@hourly':'0 * * * *','@weekly':'0 0 * * 0','@monthly':'0 0 1 * *','@yearly':'0 0 1 1 *','@once':null,'None':null,'@continuous':null};
var KNOWN=/^(Python|Bash|Empty|Dummy|SQLExecuteQuery|Postgres|MySql|Trigger|Branch|Short|Docker|Kubernetes|Email|S3ToRedshift|GCSToBigQuery)Operator$/;
function delta(s){var d=/days\s*=\s*(\d+)/.exec(s),h=/hours\s*=\s*(\d+)/.exec(s),m=/minutes\s*=\s*(\d+)/.exec(s);
  if(d)return +d[1]===1?'0 0 * * *':'0 0 */'+d[1]+' * *';if(h)return '0 */'+h[1]+' * * *';if(m)return '*/'+m[1]+' * * * *';return null}
function q(s){return '"'+String(s).replace(/"/g,'\\"')+'"'}
function cols(s){return s.split(',').map(function(x){return x.replace(/["'\s]/g,'')}).filter(Boolean)}

function secretName(s){return '${SECRET.'+String(s).toUpperCase().replace(/[^A-Z0-9]+/g,'_')+'}'}
function translate(text){
  var L=text.split('\n'),N=[],tf=[],srcs=[],dsts=[],acts=[],name=null,cron=null,manual=false,
      retries=null,backoff=null,lName=null,lCron=null,lRetry=null;
  function note(k,l,w,t){N.push({k:k,l:l,w:w,t:t})}
  function first(re){for(var i=0;i<L.length;i++){var m=re.exec(L[i]);if(m)return{m:m,l:i+1}}return null}

  var env=(/EnvVar\(\s*["']([\w.\- ]+)["']/.exec(text)||[])[1]||null;
  var res=(/context\.resources\.(\w+)/.exec(text)||[])[1]||null;
  var conn=env?secretName(env):(res?secretName(res):null);
  var hookPg=/Postgres|postgres|psycopg/.test(text),hookMy=/MySql|mysql|maria/i.test(text);

  /* --- nom : @asset(name=) | @asset + def | @job + def | define_asset_job("x") --- */
  var r=first(/@(?:multi_)?asset\([^)]*name\s*=\s*["']([\w.\- ]+)["']/);
  if(!r){for(var i=0;i<L.length;i++){if(/^\s*@(asset|multi_asset|job|graph|op|solid|pipeline)\b/.test(L[i])){
    for(var j=i+1;j<Math.min(L.length,i+8);j++){var dm=/^\s*def\s+(\w+)\s*\(/.exec(L[j]);
      if(dm){r={m:[0,dm[1]],l:j+1};break}}
    if(r)break}}}
  if(!r)r=first(/define_asset_job\(\s*["']([\w.\- ]+)["']/);
  if(r){name=r.m[1];lName=r.l;note('map',r.l,'asset name','name: '+name)}

  /* --- planification --- */
  r=first(/cron_schedule\s*=\s*["']([^"']+)["']/);
  if(r){cron=r.m[1].trim();lCron=r.l;note('map',r.l,'cron_schedule','trigger.cron: '+q(cron))}
  else{r=first(/build_schedule_from_partitioned_job/);
    if(r){var pd=/(Daily|Hourly|Weekly|Monthly)PartitionsDefinition/.exec(text);
      cron=pd?({Daily:'0 0 * * *',Hourly:'0 * * * *',Weekly:'0 0 * * 0',Monthly:'0 0 1 * *'})[pd[1]]:'0 0 * * *';
      lCron=r.l;note('map',r.l,'schedule from partitions','trigger.cron: '+q(cron)+' — derived from the partition grain')}
    else{r=first(/@schedule\b/);if(r){manual=true;lCron=r.l;note('care',r.l,'schedule without a cron','The cron is computed in Python. Hydra needs a literal — fill trigger.cron in by hand.')}}}

  /* --- reprises --- */
  r=first(/RetryPolicy\(([^)]*)\)/);
  if(r){var mr=/max_retries\s*=\s*(\d+)/.exec(r.m[1]),dl=/delay\s*=\s*(\d+)/.exec(r.m[1]);
    if(mr){retries=+mr[1];lRetry=r.l;
      if(dl)backoff=(+dl[1]%3600===0?(+dl[1]/3600)+'h':(+dl[1]%60===0?(+dl[1]/60)+'m':dl[1]+'s'));
      note('map',r.l,'RetryPolicy','retry.attempts: '+retries+(backoff?', backoff: '+backoff:''))}}

  var assets=[],adef=[];
  for(var i=0;i<L.length;i++)if(/^\s*@(asset|multi_asset)\b/.test(L[i]))
    for(var j=i+1;j<Math.min(L.length,i+9);j++){var am=/^\s*def\s+(\w+)\s*\(([^)]*)/.exec(L[j]);
      if(am){assets.push(am[1]);adef.push({n:am[1],args:am[2],l:j+1});break}}
  if(assets.length>1)note('care',adef[1].l,assets.length+' assets in one file',
    'A job is one asset: one source, one destination. These become '+assets.length+' manifests wired together by a workflow — translating them as one would silently merge them.');
  adef.forEach(function(a){
    var dep=assets.filter(function(o){return o!==a.n&&new RegExp('\\b'+o+'\\b').test(a.args)});
    if(dep.length)note('care',a.l,a.n+' depends on '+dep.join(', '),
      'An upstream asset passed as an argument becomes an upstream job: depends_on: ['+dep.map(function(d){return '"'+d+'"'}).join(', ')+'] in the workflow.');});
  var imps=[],deco=[],logs=[],wire=[],parts=[],checks=[],skipInd=-1,chkDef=0;
  for(var i=0;i<L.length;i++){
    var ln=L[i],no=i+1,m;
    if(/^\s*(from|import)\s+/.test(ln)){imps.push(no);continue}
    if(skipInd>=0){var ind=/^[ \t]*/.exec(ln)[0].length;
      if(!ln.trim()){checks.push(no);continue}
      if(chkDef===0&&/^\s*(async\s+)?def\s/.test(ln)){chkDef=1;checks.push(no);continue}
      if(ind>skipInd){checks.push(no);continue}
      skipInd=-1;chkDef=0}

    /* --- ce qui reste chez Dagster --- */
    if(/@asset_check\b/.test(ln)){checks.push(no);skipInd=/^[ \t]*/.exec(ln)[0].length;chkDef=0;continue}
    if(/AssetCheckResult/.test(ln)){checks.push(no);continue}
    if(/@multi_asset\b|AssetOut\(/.test(ln)){note('care',no,'multi_asset','One job writes one destination. Two outputs become two jobs, chained in a workflow.');continue}
    if(/AutoMaterializePolicy|AutomationCondition/.test(ln)){note('care',no,'auto-materialization','Hydra runs when triggered — there is no reactive materialization engine. This is a reason to keep Dagster on top.');continue}
    if(/FreshnessPolicy|freshness_policy/.test(ln)){note('care',no,'freshness policy','No SLA tracking in v1. Dagster keeps owning freshness; Hydra just runs the job.');continue}
    if(/PartitionsDefinition|partition_key|partition_expr/.test(ln)){parts.push(no);continue}
    if(/io_manager_key|IOManager|UPathIOManager/.test(ln)){note('care',no,'IO manager','The IO manager decides where the frame lands. Hydra needs that decision written down as a destination.');continue}
    if(/dbt_assets|DbtCliResource/.test(ln)){note('care',no,'dbt assets','dbt keeps owning its models. Hydra feeds the warehouse dbt reads from.');continue}
    if(/AssetIn\(|non_argument_deps|\bdeps\s*=\s*\[/.test(ln)){note('care',no,'asset dependency','Upstream assets become upstream jobs, wired with depends_on in a workflow.');continue}
    if(/^\s*return\s+(\w*df\w*|daily|weekly|\w+)\s*$/.test(ln)&&!/to_(parquet|csv|sql|json)/.test(text)){
      note('care',no,'returned frame','Nothing is written here — the IO manager persists the return value. Hydra has no implicit sink: name the destination.');continue}

    /* --- pure tuyauterie --- */
    if(/^\s*@(asset|multi_asset|op|job|graph|solid|pipeline|schedule|sensor)\b/.test(ln)){deco.push(no);continue}
    if(/context\.log\.|^\s*logger\.|print\(/.test(ln)){logs.push(no);continue}
    if(/Definitions\(|define_asset_job\(|ScheduleDefinition\(|^\s*(assets|schedules|resources|asset_checks)\s*=|^\s*\)$/.test(ln)){wire.push(no);continue}
    if(m=/EnvVar\(\s*["']([\w.\- ]+)["']/.exec(ln)){note('map',no,'EnvVar','Resolved as '+secretName(m[1])+' from your secret store.');continue}
    if(/context\.resources\.\w+|ConfigurableResource|get_connection\(\)/.test(ln)&&!/read_sql|to_(sql|parquet|csv|json)/.test(ln)){
      note('map',no,'resource','Becomes source.conn — one named connection instead of a resource graph.');continue}

    /* --- sources --- */
    if(m=/pd\.read_sql\(\s*f?["']([^"']+)["']/.exec(ln)){srcs.push({t:hookPg?'postgres':(hookMy?'mysql':'sql'),q:m[1],l:no,conn:conn});
      note('map',no,'read_sql','source.type: '+(hookPg?'postgres':(hookMy?'mysql':'sql')));continue}
    if(m=/pd\.read_csv\(\s*["']([^"']+)["']/.exec(ln)){srcs.push({t:'csv',p:m[1],l:no});note('map',no,'read_csv','source.type: csv');continue}
    if(m=/pd\.read_parquet\(\s*["']([^"']+)["']/.exec(ln)){srcs.push({t:'parquet',p:m[1],l:no});note('map',no,'read_parquet','source.type: parquet');continue}
    if(m=/pd\.read_json\(\s*["']([^"']+)["']/.exec(ln)){srcs.push({t:'json',p:m[1],l:no});note('map',no,'read_json','source.type: json');continue}
    if(m=/(?:requests|httpx|client)\.(?:get|post)\(\s*["']([^"']+)["']/.exec(ln)){srcs.push({t:'webapi',p:m[1],l:no});note('map',no,'HTTP call','source.type: webapi');continue}
    if(/pd\.json_normalize\(/.test(ln)){tf.push({op:'flatten',p:'{}',l:no});note('map',no,'json_normalize','op: flatten');continue}
    /* --- destinations --- */
    if(m=/\.to_parquet\(\s*["']([^"']+)["']/.exec(ln)){dsts.push({t:'parquet',p:m[1],l:no});note('map',no,'to_parquet','destination.type: parquet');continue}
    if(m=/\.to_csv\(\s*["']([^"']+)["']/.exec(ln)){dsts.push({t:'csv',p:m[1],l:no});note('map',no,'to_csv','destination.type: csv');continue}
    if(m=/\.to_sql\(\s*["']([^"']+)["']/.exec(ln)){var md=/if_exists\s*=\s*["'](\w+)["']/.exec(ln);
      dsts.push({t:hookPg?'postgres':(hookMy?'mysql':'sql'),tb:m[1],mode:md?(md[1]==='append'?'append':'replace'):'append',l:no});
      note('map',no,'to_sql','destination.type: '+(hookPg?'postgres':'sql')+', mode: '+(md?md[1]:'append'));continue}
    if(m=/\.to_json\(\s*["']([^"']+)["']/.exec(ln)){dsts.push({t:'json',p:m[1],l:no});note('map',no,'to_json','destination.type: json');continue}
    /* --- transformations --- */
    if(m=/=\s*\w+\[\[([^\]]+)\]\]/.exec(ln)){tf.push({op:'select',p:'{columns: ['+cols(m[1]).join(', ')+']}',l:no});note('map',no,'column subset','op: select');continue}
    if(m=/\.rename\(\s*columns\s*=\s*\{([^}]*)\}/.exec(ln)){tf.push({op:'rename',p:'{map: {'+m[1].replace(/["']/g,'').trim()+'}}',l:no});note('map',no,'rename','op: rename');continue}
    if(m=/\.astype\(\s*\{([^}]*)\}/.exec(ln)){tf.push({op:'cast',p:'{types: {'+m[1].replace(/["']/g,'').trim()+'}}',l:no});note('map',no,'astype','op: cast');continue}
    if(m=/\.fillna\(\s*\{([^}]*)\}/.exec(ln)){tf.push({op:'fill_null',p:'{values: {'+m[1].replace(/["']/g,'').trim()+'}}',l:no});note('map',no,'fillna','op: fill_null');continue}
    if(/\.fillna\(/.test(ln)){tf.push({op:'fill_null',p:'{}',l:no});note('map',no,'fillna','op: fill_null');continue}
    if(m=/\.drop_duplicates\(\s*(?:subset\s*=\s*\[([^\]]*)\])?/.exec(ln)){tf.push({op:'deduplicate',p:m[1]?'{keys: ['+cols(m[1]).join(', ')+']}':'{}',l:no});note('map',no,'drop_duplicates','op: deduplicate');continue}
    if(m=/\.sort_values\(\s*(?:by\s*=\s*)?["'](\w+)["']([^)]*)\)/.exec(ln)){var asc=!/ascending\s*=\s*False/.test(m[2]);
      tf.push({op:'sort',p:'{by: ['+m[1]+'], order: '+(asc?'asc':'desc')+'}',l:no});note('map',no,'sort_values','op: sort');continue}
    if(m=/\.groupby\(\s*(\[[^\]]*\]|["']\w+["'])\s*\)/.exec(ln)){
      var keys=cols(m[1].replace(/[\[\]]/g,'')),ag=/\.agg\(\s*\{([^}]*)\}/.exec(ln),p;
      if(ag){p='{by: ['+keys.join(', ')+'], agg: {'+ag[1].replace(/["']/g,'').trim()+'}}'}
      else{var cf=/\.(\w+)\.(sum|mean|count|min|max)\(/.exec(ln)||/\]\.(sum|mean|count|min|max)\(/.exec(ln);
        p=cf?(cf.length>2?'{by: ['+keys.join(', ')+'], agg: {'+cf[1]+': '+cf[2]+'}}':'{by: ['+keys.join(', ')+'], agg: {'+cf[1]+'}}'):'{by: ['+keys.join(', ')+']}'}
      tf.push({op:'aggregate',p:p,l:no});note('map',no,'groupby','op: aggregate');continue}
    if(/\.merge\(|pd\.merge\(/.test(ln)){note('care',no,'merge','Two inputs = two jobs plus a workflow join. Split before you translate.');continue}
    if(/\.apply\(|lambda\s/.test(ln)){note('care',no,'apply / lambda','Arbitrary Python has no declarative form — this becomes a plugin.');continue}
    if(m=/\w+\[\s*\w+\.(\w+)\.notnull\(\)\s*\]/.exec(ln)){tf.push({op:'filter',p:'{expr: '+q(m[1]+' is not null')+'}',l:no});note('map',no,'notnull filter','op: filter');continue}
    if(m=/\[\s*\w+[.\[]["']?(\w+)["']?\]?\s*(==|!=|>=|<=|>|<)\s*([^\]]+?)\s*\]/.exec(ln)){
      tf.push({op:'filter',p:'{expr: '+q(m[1]+' '+m[2]+' '+m[3].trim())+'}',l:no});note('map',no,'boolean mask','op: filter');continue}
    if(m=/\.query\(\s*(["'])((?:(?!\1)[\s\S])*)\1/.exec(ln)){tf.push({op:'filter',p:'{expr: '+q(m[2].replace(/'/g,'"'))+'}',l:no});note('map',no,'query()','op: filter');continue}
    if(m=/(?:pd\.read_(\w+)|\.to_(\w+))\(\s*f?["']?[^"')]*\{/.exec(ln)){
      note('care',no,'computed path','The path is built from a partition key. In Hydra that is ${run.date} inside a literal path.');continue}
    if(m=/(?:pd\.read_(\w+)|\.to_(\w+))\(\s*(?!["'])[\w(]/.exec(ln)){
      note('care',no,'computed path','The path is built at runtime. A job declares one path — use ${run.date} in it.');continue}
    var um=/\b\w*df\w*\s*\.\s*(\w+)\s*\(/.exec(ln);
    if(um&&['reset_index','copy','head','tail','info','describe','to_dict','set_index','shape','get'].indexOf(um[1])<0)
      note('care',no,'.'+um[1]+'() not translated','No built-in op matches this call, so this line produced nothing. Either it becomes a plugin, or the manifest is quietly missing a step.');
  }
  if(parts.length)note('care',parts[0],'partitions','No partition catalog in v1. A partitioned run becomes hdrctl run --from … --to …, and the partition key becomes ${run.date} inside the path.');
  if(checks.length)note('care',checks[0],'asset check','Hydra v1 has no data-quality layer. Keep the check in Dagster and let it read what Hydra wrote — this is a reason to run both.');
  if(imps.length)note('drop',imps[0],imps.length+' import'+(imps.length>1?'s':''),'A manifest is data — there is nothing to import.');
  if(deco.length)note('drop',deco[0],deco.length+' decorator'+(deco.length>1?'s':''),'@asset and @op are wiring. The manifest declares steps; nothing needs decorating.');
  if(wire.length)note('drop',wire[0],wire.length+' Definitions line'+(wire.length>1?'s':''),'The code location, the asset job and the schedule registry all collapse into the trigger block.');
  if(logs.length)note('drop',logs[0],logs.length+' logging line'+(logs.length>1?'s':''),'Every step is logged by the runner, with row counts and timings.');
  if(srcs.length>1)note('care',srcs[1].l,'second source','A job reads one source. Split into 2 jobs joined by a workflow.');
  if(dsts.length>1)note('care',dsts[1].l,'second destination','A job writes one destination. The extra one becomes its own job.');
  if(!srcs.length)note('care',1,'no source found','Nothing readable was detected — fill source: by hand.');
  if(!dsts.length)note('care',1,'no destination found','Nothing writable was detected — fill destination: by hand.');
  return {name:name||'untitled',cron:cron,manual:manual,tf:tf,src:srcs[0]||null,dst:dsts[0]||null,acts:acts,
          retries:retries,backoff:backoff,cache:null,notes:N,lName:lName,lCron:lCron,lRetry:lRetry,lCache:null,
          srcs:srcs,dsts:dsts,grp:{imp:imps,xcom:deco.concat(logs,wire),parts:parts,checks:checks}};
}

function buildYaml(t){
  var job=[],o=[],wf=t.acts.length>0;
  function J(s,l){job.push([s,l==null?null:l])}
  function O(s,l){o.push([s,l==null?null:l])}
  J('name: '+t.name,t.lName);J('');
  J('trigger:',t.lCron);
  if(t.manual||!t.cron)J('  type: manual',t.lCron);else{J('  type: schedule',t.lCron);J('  cron: '+q(t.cron),t.lCron)}
  J('');
  var s=t.src,dstFromSql=null;
  J('source:',s?s.l:null);
  if(!s){J('  type: ???        # nothing detected — fill this in',null)}
  else if(s.t==='sql'||s.t==='mysql'||s.t==='postgres'){
    var query=s.q,ins=/INSERT\s+INTO\s+([\w.]+)\s+(SELECT[\s\S]+)/i.exec(s.q||'');
    if(ins){dstFromSql=ins[1];query=ins[2]}
    J('  type: '+(s.t==='sql'?'sql':s.t),s.l);
    J('  conn: '+(s.conn||'${SECRET.DWH}'),s.l);
    J('  query: '+q(query),s.l);
  } else if(s.t==='webapi'){J('  type: webapi',s.l);J('  url: '+q(s.p),s.l);J('  method: GET',s.l)}
  else{J('  type: '+s.t,s.l);J('  path: '+q(s.p),s.l)}
  J('');
  J('transformations:',null);
  if(!t.tf.length)J('  []               # pass-through',null);
  else t.tf.forEach(function(x){J('  - op: '+x.op,x.l);if(x.p&&x.p!=='{}')J('    params: '+x.p,x.l)});
  J('');
  J('destination:',t.dst?t.dst.l:null);
  var d=t.dst;
  if(dstFromSql&&!d){J('  type: postgres',s?s.l:null);J('  table: '+dstFromSql,s?s.l:null);J('  mode: append',null)}
  else if(!d){J('  type: ???        # nothing detected — fill this in',null)}
  else if(d.tb){J('  type: '+d.t,d.l);J('  table: '+q(d.tb),d.l);J('  mode: '+d.mode,d.l)}
  else{J('  type: '+d.t,d.l);J('  path: '+q(d.p),d.l);J('  mode: replace',d.l)}
  if(t.retries!=null){J('');J('retry:',t.lRetry);J('  attempts: '+t.retries,t.lRetry);if(t.backoff)J('  backoff: '+t.backoff,t.lRetry)}
  if(t.cache){J('');J('cache:',t.lCache);J('  enabled: true',t.lCache);if(t.cache.ttl)J('  ttl: '+t.cache.ttl,t.lCache)}
  if(!wf)return job;
  O('# ─────────  jobs/'+t.name+'.yaml  ─────────',null);O('',null);
  o=o.concat(job);
  O('',null);O('# ─────────  workflows/'+t.name+'.yaml  ─────────',null);O('',null);
  O('version: "1.0"',null);O('workflow:',null);O('  name: '+t.name,t.lName);O('  trigger:',t.lCron);
  if(t.manual||!t.cron)O('    type: manual',t.lCron);else{O('    type: schedule',t.lCron);O('    cron: '+q(t.cron),t.lCron)}
  O('  steps:',null);
  var prev=null;
  t.acts.forEach(function(a,i){
    O('    - name: '+a.id,a.l);O('      type: action',a.l);O('      action: shell',a.l);O('      params:',a.l);O('        command: '+q(a.cmd),a.l);
    if(prev)O('      depends_on: ['+q(prev)+']',a.l);
    prev=a.id;
    if(i===0){O('    - name: '+t.name,null);O('      type: job',null);O('      job: "./jobs/'+t.name+'.yaml"',null);O('      depends_on: ['+q(a.id)+']',null);prev=t.name}
  });
  return o;
}
function colorLine(l){
  if(/^\s*#/.test(l))return '<span class="yc">'+l+'</span>';
  var st=[],cm=null;
  l=l.replace(/"[^"]*"/g,function(m){st.push(m);return '\u0001'+(st.length-1)+'\u0001'});
  l=l.replace(/#.*$/,function(m){cm=m;return '\u0002'});
  l=l.replace(/^(\s*(?:- )?)([\w_]+)(:)/,'$1<span class="yk">$2</span>$3');
  if(cm!==null)l=l.replace('\u0002','<span class="yc">'+cm+'</span>');
  return l.replace(/\u0001(\d+)\u0001/g,function(_,i){return '<span class="ys">'+st[+i]+'</span>'});
}
function colorYaml(rows){return rows.map(function(r,i){
  return '<span class="yl" data-i="'+i+'"'+(r[1]?' data-s="'+r[1]+'"':'')+'>'+colorLine(esc(r[0]))+'</span>'}).join('')}

/* ---------- render ---------- */
var FILT={map:1,drop:1,care:1},CUR=null,ROWS=[],IGN={},MUTE={},SEL=null;
function ignCount(){var n=0;for(var k in IGN)if(IGN[k])n++;return n}
function effective(text){
  if(!ignCount())return text;
  return text.split('\n').map(function(l,i){return IGN[i+1]?'':l}).join('\n');
}
function run(){
  var text=$("src").value;
  if(!text.trim()){$("yml").innerHTML='<span class="yc"># paste a Dagster asset on the left —\n# or pick a sample above.</span>';$("yml").dataset.raw='';
    $("fnB").textContent='job.yaml';$("cMap").textContent='0';$("cDrop").textContent='0';$("cCare").textContent='0';
    $("gut").innerHTML='<i>1</i>';$("rl").innerHTML='<li class="empty">Waiting for an asset.</li>';CUR=null;ROWS=[];return}
  var t=translate(SEL!=null?SEL.text:effective(text));CUR=t;
  ROWS=buildYaml(t);
  var y=ROWS.map(function(r){return r[0]}).join('\n');
  $("yml").innerHTML=colorYaml(ROWS);
  $("yml").dataset.raw=y;
  $("fnB").textContent=(SEL!=null?'selection · ':'')+(t.acts.length?'workflows/':'jobs/')+t.name+'.yaml';
  $("fnA").textContent=(t.name==='untitled'?'assets':t.name)+'.py'+(ignCount()?'  ('+ignCount()+' ignored)':'');
  var c={map:0,drop:0,care:0};t.notes.forEach(function(n){c[n.k]++});
  $("cMap").textContent=c.map;$("cDrop").textContent=c.drop;$("cCare").textContent=c.care;
  var hit={};t.notes.forEach(function(n){hit[n.l]=1});
  var nl=text.split('\n').length,g='';
  for(var i=1;i<=nl;i++)g+='<i class="'+(IGN[i]?'ign':(hit[i]?'hit':''))+'">'+i+'</i>';
  $("gut").innerHTML=g;
  var ns=t.notes.filter(function(n){return FILT[n.k]&&!MUTE[n.w]}).sort(function(a,b){return a.l-b.l});
  $("rl").innerHTML=ns.length?ns.map(function(n,i){
    return '<li class="'+n.k+'" data-l="'+n.l+'" data-w="'+esc(n.w)+'" data-k="'+n.k+'" tabindex="0"><span class="ln">'+n.l+'</span><span class="bd"></span><span><span class="w">'+esc(n.w)+'</span> — <span class="t">'+n.t+'</span></span></li>'}).join('')
    :'<li class="empty">Nothing to show with these filters.</li>';
  $("selBar").style.display=SEL!=null?'flex':'none';
}
var deb;
$("src").addEventListener('input',function(){$("ex").selectedIndex=-1;$("exTag").textContent='your asset';clearTimeout(deb);deb=setTimeout(run,120)});
$("src").addEventListener('scroll',function(){$("gut").scrollTop=$("src").scrollTop});
function gotoLine(n){var ta=$("src"),L=ta.value.split('\n'),p=0;
  for(var i=0;i<n-1;i++)p+=L[i].length+1;
  ta.focus();ta.setSelectionRange(p,p+(L[n-1]||'').length);
  ta.scrollTop=Math.max(0,(n-6)*LH());$("gut").scrollTop=ta.scrollTop}
$("rl").addEventListener('click',function(e){var li=e.target.closest?e.target.closest('li[data-l]'):null;if(li)gotoLine(+li.getAttribute('data-l'))});
[].slice.call(document.querySelectorAll('.cnt')).forEach(function(b){b.onclick=function(){
  var f=b.getAttribute('data-f');FILT[f]=!FILT[f];b.classList.toggle('on',FILT[f]);run()}});
$("cp").onclick=function(){cpy($("yml").dataset.raw||'');toast('Manifest copied')};
$("dl").onclick=function(){var t=$("yml").dataset.raw||'',b=new Blob([t],{type:'text/yaml'}),u=URL.createObjectURL(b),a=document.createElement('a');
  a.href=u;a.download=$("fnB").textContent.split('/').pop().replace('selection · ','');a.click();URL.revokeObjectURL(u)};
function cpy(s){if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(s)}
function LH(){var v=parseFloat(getComputedStyle($("src")).lineHeight);return isNaN(v)?19.3:v}

/* ---------- examples ---------- */
$("ex").innerHTML=EX.map(function(e,i){return '<option value="'+i+'">'+esc(e.n)+'</option>'}).join('');
$("exCount").textContent=EX.length+' samples here — 120+ in the full docs.';
function load(i){var e=EX[i];$("src").value=e.s;$("fnA").textContent=e.f;$("ex").value=i;$("exTag").textContent=e.f;run();$("src").scrollTop=0;$("gut").scrollTop=0}
$("ex").onchange=function(){load(+$("ex").value)};
$("rand").onclick=function(){var i;do{i=Math.floor(Math.random()*EX.length)}while(EX.length>1&&i===+$("ex").value);load(i)};
$("blank").onclick=function(){$("src").value='';$("fnA").textContent='assets.py';$("exTag").textContent='';run();$("src").focus()};
load(0);
/* ================= MENU CONTEXTUEL ================= */
var MENU=$("menu"),POP=$("pop"),MI=[],LASTF=null;
function toast(s){var t=$("toast");t.textContent=s;t.classList.add('on');clearTimeout(t._t);t._t=setTimeout(function(){t.classList.remove('on')},1600)}
function closeMenu(back){MENU.classList.remove('open');MENU.innerHTML='';MI=[];if(back&&LASTF&&LASTF.focus)LASTF.focus()}
function openMenu(x,y,items,head){
  LASTF=document.activeElement;MI=items;
  MENU.innerHTML=(head?'<div class="hd">'+esc(head)+'</div>':'')+items.map(function(it,i){
    return it==='-'?'<hr>':'<button role="menuitem" data-i="'+i+'"'+(it.off?' disabled':'')+'>'+esc(it.t)+(it.k?'<span class="k">'+it.k+'</span>':'')+'</button>'}).join('');
  MENU.classList.add('open');MENU.style.left='0px';MENU.style.top='0px';
  var r=MENU.getBoundingClientRect();
  MENU.style.left=Math.max(6,Math.min(x,innerWidth-r.width-8))+'px';
  MENU.style.top=Math.max(6,Math.min(y,innerHeight-r.height-8))+'px';
  var f=MENU.querySelector('button:not([disabled])');if(f)f.focus();
}
MENU.addEventListener('click',function(e){var b=e.target.closest?e.target.closest('button[data-i]'):null;if(!b)return;
  var it=MI[+b.getAttribute('data-i')];closeMenu();if(it&&it.f)it.f()});
MENU.addEventListener('keydown',function(e){
  var bs=[].slice.call(MENU.querySelectorAll('button:not([disabled])')),i=bs.indexOf(document.activeElement);
  if(e.key==='ArrowDown'){e.preventDefault();bs[(i+1)%bs.length].focus()}
  else if(e.key==='ArrowUp'){e.preventDefault();bs[(i-1+bs.length)%bs.length].focus()}
  else if(e.key==='Escape'){e.preventDefault();closeMenu(1)}});
document.addEventListener('mousedown',function(e){if(MENU.classList.contains('open')&&!MENU.contains(e.target))closeMenu()});
window.addEventListener('scroll',function(){if(MENU.classList.contains('open'))closeMenu()},true);
document.addEventListener('keydown',function(e){if(e.key==='Escape'){if(MENU.classList.contains('open'))closeMenu(1);else if(POP.classList.contains('open'))closePop()}});
function ctx(el,build){
  el.addEventListener('contextmenu',function(e){
    if(e.shiftKey)return;
    var b=build(e);if(!b)return;e.preventDefault();openMenu(e.clientX,e.clientY,b.items,b.head)});
  el.addEventListener('keydown',function(e){
    if(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')){
      var b=build(e);if(!b)return;e.preventDefault();
      var r=(e.target.getBoundingClientRect?e.target:el).getBoundingClientRect();
      openMenu(r.left+24,r.top+22,b.items,b.head)}});
}
/* ---- popover ---- */
function closePop(){POP.classList.remove('open');if(LASTF&&LASTF.focus)LASTF.focus()}
$("popX").onclick=closePop;
document.addEventListener('mousedown',function(e){if(POP.classList.contains('open')&&!POP.contains(e.target)&&!MENU.contains(e.target))closePop()});
function pop(tag,title,html,x,y){
  $("popTag").textContent=tag;$("popT").textContent=title;$("popB").innerHTML=html;
  POP.classList.add('open');POP.style.left='0px';POP.style.top='0px';
  var r=POP.getBoundingClientRect();
  POP.style.left=Math.max(8,Math.min((x||120),innerWidth-r.width-10))+'px';
  POP.style.top=Math.max(8,Math.min((y||120),innerHeight-r.height-10))+'px';
  $("popX").focus();
}
/* ---- helpers ---- */
function LN(){return $("src").value.split('\n')}
function lineAt(e){var ta=$("src"),r=ta.getBoundingClientRect(),lh=LH(),pt=parseFloat(getComputedStyle(ta).paddingTop)||0;
  var n=Math.floor((e.clientY-r.top-pt+ta.scrollTop)/lh)+1;return Math.max(1,Math.min(LN().length,n))}
function caretLine(){var ta=$("src");return ta.value.slice(0,ta.selectionStart).split('\n').length}
function pulse(n){
  [].slice.call($("yml").querySelectorAll('.yl')).forEach(function(e){e.classList.remove('pulse')});
  var hit=[].slice.call($("yml").querySelectorAll('.yl[data-s="'+n+'"]'));
  hit.forEach(function(e){e.classList.add('pulse')});
  if(hit.length){hit[0].scrollIntoView({block:'center'});return hit.length}
  return 0;
}
function blockAt(i){
  if(!ROWS.length)return null;
  var a=i;while(a>0&&!/^[A-Za-z]/.test(ROWS[a][0]))a--;
  var b=a+1;while(b<ROWS.length&&!/^[A-Za-z#]/.test(ROWS[b][0]))b++;
  while(b>a+1&&!ROWS[b-1][0].trim())b--;
  return {a:a,b:b,name:(ROWS[a][0].split(':')[0]||'').trim(),txt:ROWS.slice(a,b).map(function(r){return r[0]}).join('\n')};
}
var OPDOC={filter:'Keeps the rows matching params.expr. Column names are used bare — validate checks they exist before the run.',
 select:'Keeps only the listed columns, in that order.',
 rename:'Renames columns. A missing source column fails validate, not the run.',
 cast:'Changes dtypes. A bad cast fails loudly instead of turning into NaN.',
 fill_null:'Replaces nulls, per column or across the frame.',
 deduplicate:'Drops duplicate rows. keys narrows what counts as duplicate.',
 sort:'Orders rows — kept explicit because it decides what any downstream limit returns.',
 aggregate:'Groups by the listed columns and applies the agg functions.',
 flatten:'Expands nested JSON into flat columns — the json_normalize equivalent.'};

/* ---- reverse : bloc YAML -> pandas ---- */
function pv(s,k){var m=new RegExp(k+':\\s*(\\{[^}]*\\}|\\[[^\\]]*\\]|"[^"]*"|[\\w.]+)').exec(s||'');return m?m[1]:null}
function lst(s){return (s||'').replace(/[\[\]]/g,'').split(',').map(function(x){return x.trim()}).filter(Boolean)}
function dic(s){return (s||'').replace(/[{}]/g,'').split(',').map(function(x){var kv=x.split(':');return kv.length<2?null:[kv[0].trim(),kv.slice(1).join(':').trim()]}).filter(Boolean)}
function toPandas(x){
  var p=x.p||'';
  if(x.op==='filter'){var e=(pv(p,'expr')||'""').replace(/^"|"$/g,'');return 'df = df.query('+JSON.stringify(e)+')'}
  if(x.op==='select')return 'df = df[['+lst(pv(p,'columns')).map(function(c){return JSON.stringify(c)}).join(', ')+']]';
  if(x.op==='rename')return 'df = df.rename(columns={'+dic(pv(p,'map')).map(function(kv){return JSON.stringify(kv[0])+': '+JSON.stringify(kv[1])}).join(', ')+'})';
  if(x.op==='cast')return 'df = df.astype({'+dic(pv(p,'types')).map(function(kv){return JSON.stringify(kv[0])+': '+JSON.stringify(kv[1])}).join(', ')+'})';
  if(x.op==='fill_null')return 'df = df.fillna({'+dic(pv(p,'values')).map(function(kv){return JSON.stringify(kv[0])+': '+kv[1]}).join(', ')+'})';
  if(x.op==='deduplicate'){var k=lst(pv(p,'keys'));return 'df = df.drop_duplicates('+(k.length?'subset=['+k.map(function(c){return JSON.stringify(c)}).join(', ')+']':'')+')'}
  if(x.op==='sort'){var b=lst(pv(p,'by'))[0]||'col',o=pv(p,'order');return 'df = df.sort_values('+JSON.stringify(b)+(o==='desc'?', ascending=False':'')+')'}
  if(x.op==='aggregate'){var by=lst(pv(p,'by')),ag=dic(pv(p,'agg'));
    return 'df = df.groupby(['+by.map(function(c){return JSON.stringify(c)}).join(', ')+']).agg({'+ag.map(function(kv){return JSON.stringify(kv[0])+': '+JSON.stringify(kv[1])}).join(', ')+'}).reset_index()'}
  if(x.op==='flatten')return 'df = pd.json_normalize(payload)';
  return '# '+x.op;
}
function reverse(block){
  var t=CUR;if(!t)return '# nothing to reverse';
  if(block==='source'){var s=t.src;if(!s)return '# no source detected';
    if(s.t==='csv')return 'df = pd.read_csv('+JSON.stringify(s.p)+')';
    if(s.t==='parquet')return 'df = pd.read_parquet('+JSON.stringify(s.p)+')';
    if(s.t==='json')return 'df = pd.read_json('+JSON.stringify(s.p)+')';
    if(s.t==='webapi')return 'r = requests.get('+JSON.stringify(s.p)+')\npayload = r.json()';
    return 'with warehouse.get_connection() as conn:\n    df = pd.read_sql('+JSON.stringify(s.q||'')+', conn)'}
  if(block==='transformations')return t.tf.length?t.tf.map(toPandas).join('\n'):'# pass-through';
  if(block==='destination'){var d=t.dst;if(!d)return '# no destination detected';
    if(d.tb)return 'engine = context.resources.dwh.get_engine()\ndf.to_sql('+JSON.stringify(d.tb)+', engine, if_exists='+JSON.stringify(d.mode)+', index=False)';
    if(d.t==='parquet')return 'df.to_parquet('+JSON.stringify(d.p)+')';
    if(d.t==='csv')return 'df.to_csv('+JSON.stringify(d.p)+', index=False)';
    return 'df.to_json('+JSON.stringify(d.p)+')'}
  if(block==='trigger'||block==='name'){var fn=String(t.name).replace(/[^\w]/g,'_');
    return '@asset\ndef '+fn+'(context) -> None:\n    ...\n\njob = define_asset_job('+JSON.stringify(fn+'_job')+', selection=['+fn+'])\n'+
      'defs = Definitions(assets=['+fn+']'+(t.cron?', schedules=[ScheduleDefinition(job=job, cron_schedule='+JSON.stringify(t.cron)+')]':'')+')'}
  if(block==='retry')return '@asset(retry_policy=RetryPolicy(max_retries='+t.retries+(t.backoff?', delay='+(parseInt(t.backoff,10)*(/h$/.test(t.backoff)?3600:(/m$/.test(t.backoff)?60:1))):'')+'))';
  return '# '+block+' has no Dagster counterpart';
}
/* ---- apercu sur donnees d'exemple ---- */
function fake(col,i){
  var c=col.toLowerCase();
  if(/(^|_)id$/.test(c)||c==='id')return 1000+i;
  if(/region/.test(c))return ['EU','US','APAC','EU','US','APAC'][i%6];
  if(/country/.test(c))return ['FR','TN','ES','FR','DE','TN'][i%6];
  if(/channel|status|stage|grade|priority/.test(c))return ['paid','paid','open','paid','open','paid'][i%6];
  if(/email/.test(c))return 'user'+i+'@acme.io';
  if(/date|_at|day|created|observed/.test(c))return '2026-07-'+('0'+(10+i%18)).slice(-2);
  if(/amount|total|net|price|revenue|balance|sum/.test(c))return (120+i*37)%900+40;
  if(/count|stock|qty/.test(c))return (i*7)%40+1;
  return 'v'+i;
}
function inferCols(t){
  var c=[];
  t.tf.forEach(function(x){
    if(x.op==='select')c=lst(pv(x.p,'columns'));
    if(x.op==='aggregate'){var by=lst(pv(x.p,'by')),ag=dic(pv(x.p,'agg')).map(function(kv){return kv[0]});c=by.concat(ag)}
    if(x.op==='rename')dic(pv(x.p,'map')).forEach(function(kv){if(c.indexOf(kv[1])<0)c.push(kv[1])});
    if(x.op==='filter'){var e=(pv(x.p,'expr')||'').replace(/"/g,''),m=/^(\w+)/.exec(e.trim());if(m&&c.indexOf(m[1])<0)c.push(m[1])}
  });
  if(!c.length)c=['id','region','amount'];
  return c.slice(0,5);
}
function preview(x,y){
  var t=CUR;if(!t){toast('Nothing to preview');return}
  var n=12,steps=[{l:'source · '+(t.src?t.src.t:'?'),n:n,d:0}];
  t.tf.forEach(function(op){
    var d=0,before=n;
    if(op.op==='filter')d=Math.max(1,Math.round(n*0.28));
    else if(op.op==='deduplicate')d=Math.max(1,Math.round(n*0.12));
    else if(op.op==='aggregate'){n=3;steps.push({l:'aggregate',n:n,d:before-n});return}
    n=Math.max(1,n-d);steps.push({l:op.op,n:n,d:before-n});
  });
  var cols=inferCols(t),rows=[];
  for(var i=0;i<Math.min(n,4);i++)rows.push(cols.map(function(c){return fake(c,i)}));
  var html='<b>Row count through the pipeline</b>'+
    steps.map(function(s){return '<div class="step"><span class="n2">'+s.n+'</span><span>'+esc(s.l)+'</span>'+(s.d?'<span class="d">−'+s.d+'</span>':'')+'</div>'}).join('')+
    '<table><thead><tr>'+cols.map(function(c){return '<th>'+esc(c)+'</th>'}).join('')+'</tr></thead><tbody>'+
    rows.map(function(r){return '<tr>'+r.map(function(v){return '<td>'+esc(v)+'</td>'}).join('')+'</tr>'}).join('')+'</tbody></table>'+
    '<p style="margin:9px 0 0;font-size:12px;color:var(--text-mut)">Synthetic rows — shapes and counts only. Wire a real file in the playground to see actual values.</p>';
  pop('preview',t.name+' · dry run',html,x,y);
}

/* ================= LES TROIS MENUS ================= */
function trunc(s,n){s=String(s).trim();return s.length>n?s.slice(0,n-1)+'…':s}

/* --- 1. editeur --- */
ctx($("src"),function(e){
  var n=e.clientY!=null&&e.type==='contextmenu'?lineAt(e):caretLine();
  var ta=$("src"),line=LN()[n-1]||'',hasSel=ta.selectionStart!==ta.selectionEnd;
  var yl=CUR?$("yml").querySelectorAll('.yl[data-s="'+n+'"]').length:0;
  var items=[
    {t:'Explain this line',k:'?',f:function(){explainLine(n,e.clientX,e.clientY)}},
    {t:'Show the YAML it produced',off:!yl,f:function(){var c=pulse(n);toast(c+' line'+(c>1?'s':'')+' highlighted')}},
    '-',
    {t:'Translate the selection only',off:!hasSel,f:function(){
      SEL={text:ta.value.slice(ta.selectionStart,ta.selectionEnd)};run();toast('Selection only')}},
    {t:(IGN[n]?'Restore this line':'Ignore this line'),k:'⌥',f:function(){IGN[n]=!IGN[n];run();
      toast(IGN[n]?'Line '+n+' ignored — retranslated':'Line '+n+' restored')}},
    {t:'Clear all ignored lines',off:!ignCount(),f:function(){IGN={};run();toast('All lines restored')}},
    '-',
    {t:'Paste an asset',k:'⌘V',f:function(){
      if(navigator.clipboard&&navigator.clipboard.readText)
        navigator.clipboard.readText().then(function(txt){if(!txt)return;IGN={};SEL=null;ta.value=txt;$("ex").selectedIndex=-1;$("exTag").textContent='your asset';run();toast('Pasted')})
        .catch(function(){toast('Clipboard blocked — use ⌘V in the editor')});
      else toast('Clipboard blocked — use ⌘V in the editor')}},
    {t:'Load a random sample',k:'R',f:function(){$("rand").click()}}
  ];
  return {head:'L'+n+'  '+trunc(line||'(empty)',30),items:items};
});
function explainLine(n,x,y){
  var ns=CUR?CUR.notes.filter(function(z){return z.l===n}):[];
  if(!ns.length&&CUR&&CUR.grp){
    ['imp','xcom'].forEach(function(g){
      if(CUR.grp[g].indexOf(n)>=0){var anchor=CUR.grp[g][0];
        ns=CUR.notes.filter(function(z){return z.l===anchor&&/import|XCom/.test(z.w)})}});}
  var out=CUR?ROWS.filter(function(r){return r[1]===n}).map(function(r){return r[0]}):[];
  var line=LN()[n-1]||'';
  var html='<pre>'+esc(trunc(line,120))+'</pre>';
  if(ns.length)html+=ns.map(function(z){
    var lab=z.k==='map'?'maps':(z.k==='drop'?'no longer needed':'needs a decision');
    return '<p style="margin:10px 0 0"><b>'+esc(z.w)+'</b> — '+lab+'<br>'+z.t+'</p>'}).join('');
  else html+='<p style="margin:10px 0 0">The parser read nothing on this line. It is either scaffolding, a comment, or a construct that has no Hydra counterpart — in which case it appears nowhere in the manifest.</p>';
  if(out.length)html+='<p style="margin:10px 0 4px"><b>Produced:</b></p><pre>'+esc(out.join('\n'))+'</pre>';
  pop(ns.length?ns[0].k:'info','Line '+n,html,x,y);
}
$("selOut").onclick=function(){SEL=null;run();toast('Full file')};

/* --- 2. ligne de rapport --- */
ctx($("rl"),function(e){
  var li=e.target.closest?e.target.closest('li[data-l]'):null;
  if(!li)li=document.activeElement&&document.activeElement.matches&&document.activeElement.matches('li[data-l]')?document.activeElement:null;
  if(!li)return null;
  var n=+li.getAttribute('data-l'),w=li.getAttribute('data-w'),k=li.getAttribute('data-k');
  var note=CUR?CUR.notes.filter(function(z){return z.l===n&&z.w===w})[0]:null;
  var cmd=note?(/(hdrctl[^.]*)/.exec(note.t)||[])[1]:null;
  return {head:trunc(w,32),items:[
    {t:'Reveal in the source',k:'↵',f:function(){gotoLine(n)}},
    {t:'Copy the suggested command',off:!cmd,f:function(){cpy(cmd);toast('Copied: '+trunc(cmd,40))}},
    {t:'Explain this line',f:function(){explainLine(n,e.clientX||160,e.clientY||160)}},
    '-',
    {t:'Mute "'+trunc(w,18)+'"',f:function(){MUTE[w]=1;run();toast('Muted — '+trunc(w,24))}},
    {t:'Unmute everything',off:!Object.keys(MUTE).length,f:function(){MUTE={};run();toast('All warnings back')}}
  ]};
});

/* --- 3. volet YAML --- */
ctx($("yml"),function(e){
  if(!ROWS.length)return null;
  var el=e.target.closest?e.target.closest('.yl'):null;
  var i=el?+el.getAttribute('data-i'):0,b=blockAt(i);
  var txt=ROWS[i]?ROWS[i][0]:'',om=/-\s*op:\s*(\w+)/.exec(txt)||(b&&b.name==='transformations'?/op:\s*(\w+)/.exec(txt):null);
  if(!om&&b&&b.name==='transformations'){for(var j=i;j>=b.a;j--){var t2=/-\s*op:\s*(\w+)/.exec(ROWS[j][0]);if(t2){om=t2;break}}}
  var src=ROWS[i]?ROWS[i][1]:null;
  return {head:b?b.name+':':'yaml',items:[
    {t:'Copy this block',k:'⌘C',off:!b,f:function(){cpy(b.txt);toast('Copied '+b.name+': ('+(b.b-b.a)+' lines)')}},
    {t:om?'Explain op: '+om[1]:'Explain this op',off:!om,f:function(){
      pop('op','op: '+om[1],'<p>'+(OPDOC[om[1]]||'Built-in operation.')+'</p><pre>'+esc(ROWS.slice(Math.max(b.a,i-1),i+2).map(function(r){return r[0]}).join('\n'))+'</pre>',e.clientX,e.clientY)}},
    {t:'Reveal the Dagster line',off:!src,f:function(){gotoLine(src);toast('Line '+src)}},
    '-',
    {t:'Back to Dagster (this block)',off:!b,f:function(){
      pop('reverse',b.name+': → Python','<p>The same block, expressed back as Dagster. Nothing here is a one-way door.</p><pre>'+esc(reverse(b.name))+'</pre>',e.clientX,e.clientY)}},
    {t:'Preview on sample data',f:function(){preview(e.clientX,e.clientY)}},
    '-',
    {t:'Copy the whole manifest',f:function(){cpy($("yml").dataset.raw||'');toast('Manifest copied')}},
    {t:'Download',f:function(){$("dl").click()}}
  ]};
});

/* ================= BARRES D'ICONES ================= */
function loadText(txt,label){IGN={};MUTE={};SEL=null;$("src").value=txt;
  $("ex").selectedIndex=-1;$("exTag").textContent=label||'your asset';run();
  $("src").scrollTop=0;$("gut").scrollTop=0}
/* --- ouvrir un fichier (bouton + glisser-deposer) --- */
$("icOpen").onclick=function(){$("fileIn").click()};
$("fileIn").onchange=function(e){var f=e.target.files[0];if(!f)return;
  var r=new FileReader();r.onload=function(){loadText(String(r.result),f.name);toast(f.name+' loaded')};r.readAsText(f);e.target.value=''};
(function(){var z=$("src").parentNode;
 ['dragenter','dragover'].forEach(function(t){z.addEventListener(t,function(e){e.preventDefault();z.classList.add('drop')})});
 ['dragleave','drop'].forEach(function(t){z.addEventListener(t,function(e){e.preventDefault();z.classList.remove('drop')})});
 z.addEventListener('drop',function(e){var f=e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files[0];if(!f)return;
   var r=new FileReader();r.onload=function(){loadText(String(r.result),f.name);toast(f.name+' dropped')};r.readAsText(f)});})();
/* --- coller --- */
$("icPaste").onclick=function(){
  if(navigator.clipboard&&navigator.clipboard.readText)
    navigator.clipboard.readText().then(function(t){if(t){loadText(t);toast('Pasted')}})
    .catch(function(){toast('Clipboard blocked — click the editor and press Ctrl/Cmd+V')});
  else{$("src").focus();toast('Press Ctrl/Cmd+V in the editor')}};
/* --- retour a la ligne (la gouttiere se retire, les numeros ne suivraient plus) --- */
/* --- parcourir les points de decision --- */
var NEXTi=-1;
function careLines(){if(!CUR)return [];
  var seen={},out=[];
  CUR.notes.forEach(function(n){if(n.k==='care'&&!MUTE[n.w]&&!seen[n.l]){seen[n.l]=1;out.push(n)}});
  return out.sort(function(a,b){return a.l-b.l})}
function syncNext(){var b=$("icNext"),c=careLines().length;
  b.disabled=!c;
  b.setAttribute('data-tip',c?('Next decision point — '+c+' to review'):'No decision left to review');
  b.classList.toggle('on',!!c)}
$("icNext").onclick=function(){var c=careLines();if(!c.length)return;
  NEXTi=(NEXTi+1)%c.length;var n=c[NEXTi];
  gotoLine(n.l);pulse(n.l);
  var li=$("rl").querySelector('li[data-l="'+n.l+'"]');if(li)li.scrollIntoView({block:'nearest'});
  toast('L'+n.l+' · '+n.w+'  ('+(NEXTi+1)+'/'+c.length+')')};
/* --- agrandir un volet --- */
function expand(side){var t=document.querySelector('.two'),cl='exp'+side,on=t.classList.toggle(cl);
  t.classList.remove(side==='L'?'expR':'expL');
  [['L','icExpL'],['R','icExpR']].forEach(function(pair){var b=$(pair[1]);if(!b)return;
    var a=t.classList.contains('exp'+pair[0]);b.classList.toggle('on',a);b.setAttribute('aria-pressed',a);
    b.setAttribute('data-tip',a?'Restore both panes':'Expand this pane')});
  return on}
$("icExpL").onclick=function(){expand('L')};
$("icExpR").onclick=function(){expand('R')};
/* --- dry run / reverse / provenance --- */
$("icRun").onclick=function(){var r=this.getBoundingClientRect();preview(r.left-330,r.bottom+8)};
$("icRev").onclick=function(){
  if(!CUR){toast('Nothing to reverse');return}
  var out=[reverse('name'),'',reverse('source'),'',reverse('transformations'),'',reverse('destination')];
  if(CUR.retries!=null)out.unshift(reverse('retry'),'');
  var r=this.getBoundingClientRect();
  pop('reverse',CUR.name+' → Dagster','<p>The whole manifest, back as an asset. Round-tripping is not a one-way door.</p><pre>'+esc(out.join('\n'))+'</pre>',r.left-340,r.bottom+8)};
$("icProv").onclick=function(){var on=$("yml").classList.toggle('prov');
  this.classList.toggle('on',on);this.setAttribute('aria-pressed',on);
  this.setAttribute('data-tip',on?'Hide provenance':'Show provenance');
  if(on)toast('Teal bar = traced back to a source line')};
$("yml").addEventListener('mouseover',function(e){
  if(!$("yml").classList.contains('prov'))return;
  var el=e.target.closest?e.target.closest('.yl[data-s]'):null;
  [].slice.call($("gut").children).forEach(function(i){i.classList.remove('hit2')});
  if(el){var g=$("gut").children[+el.getAttribute('data-s')-1];if(g)g.style.outline='2px solid var(--accent)'}
});
$("yml").addEventListener('mouseout',function(){[].slice.call($("gut").children).forEach(function(i){i.style.outline=''})});
/* --- pastille des lignes ignorees --- */
$("icIgn").onclick=function(){IGN={};run();toast('All lines restored')};
var _run=run;
run=function(){_run();NEXTi=-1;syncNext();var n=ignCount(),b=$("icIgn");
  b.style.display=n?'grid':'none';$("icIgnN").textContent=n;
  b.setAttribute('data-tip',n===1?'Restore 1 ignored line':'Restore '+n+' ignored lines')};
run();

/* ================= LINT ================= */
function lintPy(text){
  var L=text.split('\n'),out=[];
  function add(s,l,w,t){out.push({s:s,l:l,w:w,t:t})}
  var SMART=new RegExp('['+String.fromCharCode(8220,8221,8216,8217)+']');
  var NBSP=new RegExp(String.fromCharCode(160));
  /* --- 1. tokenizer : chaines, triples quotes, commentaires --- */
  var st=null,depth=0,dl=0,bs=false,info=[];
  for(var i=0;i<L.length;i++){
    var raw=L[i],no=i+1,code='',cont=(depth>0)||st!==null||bs,j=0;
    while(j<raw.length){
      var ch=raw.charAt(j),two=raw.substr(j,3);
      if(st){
        if(st.length===3){if(two===st){st=null;j+=3;continue}}
        else{if(ch==='\\'){j+=2;continue}if(ch===st){st=null;j++;continue}}
        code+=' ';j++;continue;
      }
      if(ch==='#')break;
      if(two==='"""'||two==="'''"){st=two;code+='  ';j+=3;continue}
      if(ch==='"'||ch==="'"){st=ch;code+=' ';j++;continue}
      if('([{'.indexOf(ch)>=0){depth++;dl=no}
      else if(')]}'.indexOf(ch)>=0){depth--;if(depth<0){add('err',no,'unbalanced bracket','A closing bracket has no opener.');depth=0}}
      code+=ch;j++;
    }
    if(st&&st.length===1)st=null;
    bs=/\\$/.test(raw.replace(/\s+$/,''));
    info.push({no:no,code:code,raw:raw,cont:cont,ind:/^[ \t]*/.exec(raw)[0].length,blank:!raw.trim()});
  }
  if(st)add('err',L.length,'unterminated string','A triple-quoted string is never closed.');
  if(depth>0)add('err',dl,'unclosed bracket',depth+' bracket'+(depth>1?'s':'')+' opened and never closed — the paste is probably truncated.');
  /* --- 2. lignes logiques : une instruction peut occuper plusieurs lignes --- */
  var lg=[],cur=null;
  info.forEach(function(x){
    if(x.blank)return;
    if(x.cont&&cur){cur.code+=' '+x.code.replace(/^[ \t]+/,'');return}
    cur={no:x.no,code:x.code,ind:x.ind};lg.push(cur);
  });
  /* --- 3. structure --- */
  var KW=/^(def|class|if|elif|else|for|while|with|try|except|finally|match|case|async|lambda)\b/;
  var prev=null;
  lg.forEach(function(x){
    var c=x.code.replace(/\s+$/,''),head=c.replace(/^[ \t]*/,'');
    if(/:$/.test(c)&&!KW.test(head)&&!/^@/.test(head))
      add('err',x.no,'statement ends with ":"','Python cannot parse this — a colon only closes a block header. A def, if, for or with is missing.');
    if(prev&&x.ind>prev.ind&&!/:$/.test(prev.code.replace(/\s+$/,'')))
      add('err',x.no,'unexpected indent','This line is indented, but line '+prev.no+' opens no block.');
    prev=x;
  });
  /* --- 4. copier-coller et pieges de version Dagster --- */
  info.forEach(function(x){
    var ln=x.raw,no=x.no;
    if(SMART.test(ln))add('err',no,'smart quotes','Curly quotes from a word processor — Python will not parse this line.');
    if(NBSP.test(ln))add('err',no,'non-breaking space','An invisible U+00A0 sits in this line — the classic copy-paste from a web page.');
    if(/^\t+/.test(ln))add('warn',no,'tab indent','Tabs mixed into Python indentation. Convert to spaces before running.');
    if(/@solid\b|\bsolid\b\s*\(|from\s+dagster\s+import[^\n]*\bsolid\b/.test(x.code))add('err',no,'@solid','Removed in Dagster 1.0. Solids became ops, and ops are largely superseded by assets.');
    if(/@pipeline\b|from\s+dagster\s+import[^\n]*\bpipeline\b/.test(x.code))add('err',no,'@pipeline','Removed in Dagster 1.0 — replaced by @job, then by asset jobs.');
    if(/ModeDefinition|PresetDefinition/.test(x.code))add('err',no,'ModeDefinition / PresetDefinition','Removed in Dagster 1.0. Resources and config are declared on Definitions now.');
    if(/context\.solid_config|context\.solid\b/.test(x.code))add('err',no,'context.solid','Removed with solids. Use context.op_config or a Config class.');
    if(/AssetGroup|build_assets_job/.test(x.code))add('err',no,'AssetGroup / build_assets_job','Removed in Dagster 1.1 — use Definitions and define_asset_job.');
    if(/non_argument_deps/.test(x.code))add('warn',no,'non_argument_deps','Deprecated since 1.5 — use deps=[...].');
    if(/AutoMaterializePolicy/.test(x.code))add('info',no,'AutoMaterializePolicy','Superseded by AutomationCondition in Dagster 1.8+.');
    if(/FreshnessPolicy\(/.test(x.code))add('info',no,'FreshnessPolicy','Reworked in recent versions — check it still means what you expect.');
    if(/@repository\b/.test(x.code))add('info',no,'@repository','Superseded by Definitions, which is what dagster dev looks for first.');
    if(/EnvVar\(/.test(x.code)&&!/from\s+dagster\s+import[^\n]*EnvVar/.test(text))add('warn',no,'EnvVar not imported','EnvVar is used but never imported from dagster.');
  });
  if(/@asset\b|@multi_asset\b/.test(text)&&!/Definitions\(|@repository\b/.test(text))
    add('warn',1,'assets never registered','No Definitions object — dagster dev will not discover these assets.');
  if(/@asset\b/.test(text)&&/->\s*pd\.DataFrame/.test(text)&&!/to_(parquet|csv|sql|json)/.test(text))
    add('info',1,'persisted by the IO manager','This asset returns a frame and writes nothing itself. Where it lands depends on the IO manager configuration, not on this file.');
  if(!/@asset\b|@multi_asset\b|@op\b|@job\b|@solid\b|@pipeline\b/.test(text)){
    out=out.filter(function(x){return x.w!=='top-level I/O'});
    add('info',1,'no asset found','Parsed as a plain pandas script — the trigger falls back to manual.');}
  out.sort(function(a,b){return a.l-b.l});
  return out;
}

function lintYaml(rows,t){
  var out=[];function add(s,i,w,tx){out.push({s:s,i:i,w:w,t:tx})}
  var seen={};
  rows.forEach(function(r,i){
    var l=r[0];
    if(/\?\?\?/.test(l))add('err',i,'unresolved field','The parser found nothing here. Fill it in before running.');
    if(/\$\{SECRET\./.test(l))add('info',i,'secret placeholder','Wire this to your secret store — a manifest never holds credentials.');
    if(/\{\{/.test(l))add('warn',i,'template left in place','Dagster templating is not evaluated by Hydra. Use ${run.date} or ${env.X}.');
    var k=/^([A-Za-z_]+):/.exec(l);
    if(k){if(seen[k[1]])add('err',i,'duplicate key','"'+k[1]+'" appears twice — the second one silently wins in most YAML parsers.');seen[k[1]]=1}
    var cm=/cron:\s*"([^"]*)"/.exec(l);
    if(cm&&cm[1].trim().split(/\s+/).length!==5)add('err',i,'malformed cron','"'+cm[1]+'" does not have 5 fields.');
    var om=/-\s*op:\s*(\w+)/.exec(l);
    if(om&&!OPDOC[om[1]])add('warn',i,'unknown op','"'+om[1]+'" is not a built-in operation — it needs a plugin.');
  });
  if(t){
    if(t.name==='untitled')add('warn',0,'no name','No dag_id was found, so the job is called "untitled".');
    if(!t.tf.length)add('info',0,'no transformation','A pass-through job — it copies the source to the destination unchanged.');
  }
  return out;
}
function lintHTML(items,mode){
  if(!items.length)return '<p style="color:var(--ok)"><b>Nothing to report.</b> No formatting problem, no version trap, no unresolved field.</p>';
  var c={err:0,warn:0,info:0};items.forEach(function(x){c[x.s]++});
  return '<p style="margin:0 0 8px">'+c.err+' blocking &middot; '+c.warn+' worth fixing &middot; '+c.info+' for information</p><ul class="lint">'+
    items.map(function(x){
      var ref=mode==='py'?(' data-goto="'+x.l+'"'):(x.i!=null?' data-yl="'+x.i+'"':'');
      return '<li'+ref+'><span class="sv '+x.s+'"></span><span class="ln2">'+(mode==='py'?x.l:(x.i!=null?x.i+1:''))+'</span>'+
        '<span><span class="w2">'+esc(x.w)+'</span><br><span class="t2">'+esc(x.t)+'</span></span></li>'}).join('')+'</ul>';
}
function sev(items){return items.some(function(x){return x.s==='err'})?'err':(items.some(function(x){return x.s==='warn'})?'warn':(items.length?'info':'ok'))}
function paint(btn,items,label){
  var s=sev(items);btn.classList.remove('sev-ok','sev-warn','sev-err');
  if(s==='err')btn.classList.add('sev-err');else if(s==='warn')btn.classList.add('sev-warn');else if(s==='ok')btn.classList.add('sev-ok');
  var n=items.length;
  btn.setAttribute('data-tip',n?(label+' — '+n+' finding'+(n>1?'s':'')):(label+' — all clear'));
}
$("icLint").onclick=function(){var it=lintPy($("src").value),r=this.getBoundingClientRect();
  pop(sev(it)==='ok'?'clean':sev(it),'Code check',lintHTML(it,'py'),r.left-40,r.bottom+8)};
$("icVal").onclick=function(){var it=lintYaml(ROWS,CUR),r=this.getBoundingClientRect();
  pop(sev(it)==='ok'?'clean':sev(it),'hdrctl validate',lintHTML(it,'yaml'),r.left-340,r.bottom+8)};
$("popB").addEventListener('click',function(e){
  var li=e.target.closest?e.target.closest('li[data-goto],li[data-yl]'):null;if(!li)return;
  if(li.hasAttribute('data-goto')){closePop();gotoLine(+li.getAttribute('data-goto'))}
  else{var el=$("yml").querySelector('.yl[data-i="'+li.getAttribute('data-yl')+'"]');
    if(el){[].slice.call($("yml").querySelectorAll('.yl')).forEach(function(x){x.classList.remove('pulse')});
      el.classList.add('pulse');el.scrollIntoView({block:'center'})}}});
var _run2=run;
run=function(){_run2();
  paint($("icLint"),$("src").value.trim()?lintPy($("src").value):[],'Check the code');
  paint($("icVal"),ROWS.length?lintYaml(ROWS,CUR):[],'Validate the manifest')};
run();